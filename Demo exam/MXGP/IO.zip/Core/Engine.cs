﻿using MXGP.Core.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace MXGP.Core
{
    public class Engine : IEngine
    {
        public void Run()
        {
            throw new NotImplementedException();
        }
    }
}
